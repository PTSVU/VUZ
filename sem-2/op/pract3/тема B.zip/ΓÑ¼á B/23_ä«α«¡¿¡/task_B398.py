# Набирая текст Джон вместо символа ‘a’ нажимает на клавишу caps lock.
# Написать функцию fat_fingers, которая исправляет данные опечатки в предложении
#
# Пример:
# fat_fingers("orNGE pple peR") ==> "orange apple pear"



import traceback


def fat_fingers(sentence):
    # Тело функции
    return ""


# Тесты
try:
    assert fat_fingers("the quick brown fox jumps over the lZY DOG") == "the quick brown fox jumps over the lazy dog"
    assert fat_fingers("orNGE pple peR") == "orange apple pear"
    assert fat_fingers("The end of the institution mINTENnce ND dministrTION OF GOVERNMENT IS TO SECURE THE EXISTENCE OF THE BODY POLITIC TO PROTECT IT nd to furnish the individuLS WHO COMPOSE IT WITH THE POWER OF ENJOYING IN Sfety ND TRnquillity their nTURl rights ND THE BLESSINGS OF LIFE nd whenever these greT OBJECTS re not obtINED THE PEOPLE Hve  RIGHT TO lter the government ND TO Tke meSURES NECESSry for their sFETY PROSPERITY nd hPPINESS") \
           == "The end of the institution, maintenance, and administration of government, is to secure the existence of the body politic, to protect it, and to furnish the individuals who compose it with the power of enjoying in safety and tranquillity their natural rights, and the blessings of life: and whenever these great objects are not obtained, the people have a right to alter the government, and to take measures necessary for their safety, prosperity and happiness"
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
