# Написать функцию decrypt, которая подсчитывает количество вхождений символов с 'a' до 'z' и 
# возвращает строку длиной 26 символов, где на каждой позиции - количетво вхождений этой буквы в строке. 
# Буквы должны быть упорядочены, как в алфавите.
#
# Примеры:
# decrypt('$aaaa#bbb*cc^fff!z') ==> '43200300000000000000000001'
#           ^    ^   ^  ^  ^         ^^^  ^                   ^
#          [4]  [3] [2][3][1]        abc  f                   z


import traceback


def decrypt(key):
    # Тело функции
    return ""


# Тесты
try:
    assert decrypt('$aaaa#bbb*ccfff!z') == '43200300000000000000000001'
    assert decrypt('z$aaa#ccc%eee1234567890') == '30303000000000000000000001'
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
