# Написать функцию spin_words, которая возвращает заданную строку,
# но переворачивает в обратном порядке все слова, состоящие из 5 или более букв
#
# Примеры:
# spin_words("This is a test") ==> "This is a test"
# spin_words("This is another test" ) ==> "This is rehtona test"

import traceback


def spin_words(sentence):
    # Тело функции
    return ""


# Тесты
try:
    assert spin_words("This is a test") == "This is a test"
    assert spin_words("notsuoH we have a melborp") == "Houston we have a problem"
    assert spin_words("Elementary my dear Watson") == "yratnemelE my dear nostaW"
    assert spin_words("Run tserroF run") == "Run Forrest run"
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
