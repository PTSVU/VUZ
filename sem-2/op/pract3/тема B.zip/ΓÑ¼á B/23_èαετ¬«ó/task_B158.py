# Написать функцию olympic_ring, которая считает количество колец в заданной строке
# латинских букв (в символе 'a' - одно кольцо, в 'B' - два). Количество колец нужно
# поделить пополам и округлить в меньшую сторону. Если результат равен 1 или меньше -
# верните «Not even a medal!», если счет равен 2 - вернуть «Bronze!»,
# если счет равен 3 - «Silver!», если оценка больше 3 - вернуть «Gold!»;
#
# Примеры:
# olympic_ring("QWertYuIoP") ==> 4 // 2 = 2 ==> "Bronze!"

import traceback


def olympic_ring(s):
    # Тело функции
    return ""


# Тесты
try:
    assert olympic_ring("wHjMudLwtoPGocnJ") == "Bronze!"
    assert olympic_ring("eCEHWEPwwnvzMicyaRjk") == "Bronze!"
    assert olympic_ring("JKniLfLW") == "Not even a medal!"
    assert olympic_ring("EWlZlDFsEIBufsalqof") == "Silver!"
    assert olympic_ring("IMBAWejlGRTDWetPS") == "Gold!"
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
