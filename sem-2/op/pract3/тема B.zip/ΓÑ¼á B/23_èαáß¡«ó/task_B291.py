# Написать функцию camel_to_snake, которая меняет слова написанные CamelCase,
# на написание snake_case
#
# Примеры:
# camel_to_snake("CamelToSnake") ==> "camel_to_snake"

import traceback


def camel_to_snake(s):
    # Тело функции
    return ""


# Тесты
try:
    assert camel_to_snake("CamelToSnake") == "camel_to_snake"
    assert camel_to_snake("FunctionAndVariable names") ==  "function_and_variable names"
    assert camel_to_snake("class MySuperClass def my_function") == "class my_super_class def my_function"
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
