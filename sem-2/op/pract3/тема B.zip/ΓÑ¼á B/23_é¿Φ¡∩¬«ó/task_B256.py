# Написать функцию high_score, которая из строки слов возвращает слово с максимальным количеством очков.
# Очки считаются по буквам, где a = 1, b = 2, c = 3, d = 4, ...
#
# Примеры:
# high_score("abc aaf") == "aaf" ("abc"= 1+2+3 = 6, "aaf" = 1+1+6 = 8)

import traceback


def high_score(s):
    # Тело функции
    return ""


# Тесты
try:
    assert high_score('abcd ef') == 'ef'
    assert high_score('what time are we climbing up the volcano') == 'volcano'
    assert high_score('zcfjyj ivsrnnelok gfuckq puhid xxituwu lzs bbzkyb kqvg kmfvfg') == 'xxituwu'
    assert high_score('qjfxvxb pgtkr dhojthinm dyr cjne') == 'qjfxvxb'
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
