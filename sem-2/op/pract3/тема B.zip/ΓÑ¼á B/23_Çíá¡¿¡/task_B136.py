# Некоторые английские слова (например, CAFE, FACADE) могут быть интерпретированы
# как шестнадцатеричные числа. Написать функцию hex_word_sum, которая вернет
# десятичную сумму всех слов в строке, которые могут быть интерпретированы как такие
# шестнадцатеричные значения. Входящие строки - в верхнем регистре, не содержат знаков препинания
# Буквы 'O' и 'S' можно воспринимать как цифры 0 и 5 соответственно.
#
# Примеры:
# "BAG" ==> 0 недопустимое шестнадцатеричное значение
# "OF" ==> 0F ==> 15
# "BEES" ==> BEE5 ==> 48869
# hex_word_sum("BAG OF BEES") ==> 48884.


import traceback


def hex_word_sum(s):
    # Тело функции
    return ""


# Тесты
try:
    assert hex_word_sum('DEFACE') == 14613198
    assert hex_word_sum('SAFE') == 23294
    assert hex_word_sum('CODE') == 49374
    assert hex_word_sum('BUGS') == 0
    assert hex_word_sum('') == 0
    assert hex_word_sum('DO YOU SEE THAT BEE DRINKING DECAF COFFEE') == 13565769
    assert hex_word_sum('ASSESS ANY BAD CODE AND TRY AGAIN') == 10889952
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")