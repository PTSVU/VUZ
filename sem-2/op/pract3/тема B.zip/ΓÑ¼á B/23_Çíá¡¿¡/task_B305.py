# Написать функцию roman_decoder, которая будет принимать строку (римское число)
# и возвращает число в привычном формате.
# Значения: I = 1; V = 5; X = 10; L = 50; C = 100; D = 500; M = 1000.
#
# Пример:
# roman_decoder("XXI") ==> 21
# roman_decoder("IV") ==> 4


import traceback


def roman_decoder(s):
    # Тело функции
    return 0


# Тесты
try:
    assert roman_decoder('XXI') == 21
    assert roman_decoder('I') == 1
    assert roman_decoder('IV') == 4
    assert roman_decoder('MMVIII') == 2008
    assert roman_decoder('MDCLXVI') == 1666
    assert roman_decoder('MMXX') == 2020
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
