# Написать функцию is_anagram, которая определяет является ли первое заданное
# слово анаграммой для второго в независимости от регистра.
# Анаграмма – результат перестановки букв в оригинальном слове
#
# Пример:
# "foefet", "toffee" ==> True


import traceback


def is_anagram(test, original):
    # Тело функции
    return True


# Тесты
try:
    assert is_anagram('Creative', 'Reactive') == True
    assert is_anagram("foefet", "toffee") == True
    assert is_anagram("Buckethead", "DeathCubeK") == True
    assert is_anagram("Twoo", "WooT") == True
    assert is_anagram("dumble", "bumble") == False
    assert is_anagram("ound", "round") == False
    assert is_anagram("apple", "pales") == False
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")