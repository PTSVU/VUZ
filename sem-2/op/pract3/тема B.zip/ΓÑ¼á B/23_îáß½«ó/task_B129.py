# Написать функцию calculate, которая выполняет сложение и вычитание данной строки
#
# Пример:
# calculate("2plus3minus1") ==> 4

import traceback


def calculate(s):
    # Тело функции
    return 0


# Тесты
try:
    assert calculate('1plus2plus3plus4') == 10
    assert calculate('1minus2minus3minus4') == -8
    assert calculate('1plus2plus3minus4') == 2
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
