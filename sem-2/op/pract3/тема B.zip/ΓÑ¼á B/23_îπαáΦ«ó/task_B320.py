# Написать функцию frame(text, char), которая заключает список строк text в рамку из
# символов char и возвращает данную строку
#
# Пример:
# frame(['Create', 'a', 'frame'], '+') ==>
# ++++++++++
# + Create +
# + a      +
# + frame  +
# ++++++++++



import traceback


def frame(text, char):
    # Тело функции
    return ""


# Тесты
try:
    assert frame(["Small", "text", "frame"], '~') == \
"""~~~~~~~~~
~ Small ~
~ text  ~
~ frame ~
~~~~~~~~~"""
    assert frame(["This is a very long single frame"], '-') == \
"""------------------------------------
- This is a very long single frame -
------------------------------------"""
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
