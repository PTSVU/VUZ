# Написать функцию numeric_formatter(template, number) для форматирования номера number по заданному шаблону
# template (если number - пустая строка, используйте цифры 1234567890 для заполнения пробелов)
#
# Правила:
# - шаблон может состоять из других цифр, специальных символов: необходимо заменить только буквы алфавита;
# - если заданная строка, представляющая число, короче шаблона, просто повторите ее, чтобы заполнить все пробелы.
#
# Примеры:
# numeric_formatter("+555 aaaa bbbb", "18031978") == "+555 1803 1978"
# numeric_formatter("+555 aaaa bbbb") == "+555 1234 5678"

import traceback


def numeric_formatter(template, number = ""):
    # Тело функции
    return ""


# Тесты
try:
    assert numeric_formatter("xxx xxxxx xx", "5465253289") == "546 52532 89"
    assert numeric_formatter("xxx xxxxx xx") == "123 45678 90"
    assert numeric_formatter("+555 aaaa bbbb", "18031978") == "+555 1803 1978"
    assert numeric_formatter("+555 aaaa bbbb") == "+555 1234 5678"
    assert numeric_formatter("xxxx yyyy zzzz") == "1234 5678 9012"
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
