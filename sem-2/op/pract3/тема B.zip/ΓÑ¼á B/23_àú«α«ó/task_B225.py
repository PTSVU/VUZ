# Написать функцию reverser, которая меняет порядок букв в каждом слове заданного
# предложения на противоположный, порядок слов при этом должен сохраниться
#
# Пример:
# reverser("reverse letters") ==> "esrever srettel"


import traceback


def reverser(sentence):
    # Тело функции
    return ""


# Тесты
try:
    assert reverser("reverse letters") == "esrever srettel"
    assert reverser("A fun little challenge!") == "A nuf elttil !egnellahc"
    assert reverser("  ") == "  "
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")