# Написать функцию chocolates(small, big, goal), которая определяет количество конфет, необходимых для 
# составления набора нужного веса (goal). Два типа конфет: маленькие и большие имеют вес small и big соотвественно.
# Функция должна вернуть спсиок из двух значений: [кол-во маленьких конфет, кол-во больших конфет]. 
# При этом набор должен составляться так, чтобы итоговое кол-во конфет в наборе было минимальным. 
# Если составить набор невозможно, необходимо вернуть [-1, -1]
#  
# Пример
# chocolates (4, 5, 14) ==> [1, 2] --> 1 * 4 + 2 * 5
# chocolates (4, 5, 13) ==> [-1, -1]


import traceback


def chocolates(small, big, goal):
    # Тело функции
    return []


# Тесты
try:
    assert chocolates(1,5,12) == [2,2]  
    assert chocolates(2,8,27) == [-1,-1]  
    assert chocolates(3,10,100) == [0,10]    
    assert chocolates(2,3,5) == [1,1]  
    assert chocolates(4,9,40) == [1,4] 
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
