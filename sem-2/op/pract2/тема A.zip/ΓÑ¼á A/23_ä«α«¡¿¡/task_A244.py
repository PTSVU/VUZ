# Написать функцию sum_consecutives, которая в списке просуммирует подряд идущие одинаковые цифры и
# заменит в списке их последовательность суммой.
#
# Пример:
# [1,4,4,4,0,4,3,3,1] ==> [1,12,0,4,6,1]


import traceback


def sum_consecutives(arr):
    # Тело функции
    return []


# Тесты
try:
    assert sum_consecutives([1, 4, 4, 4, 0, 4, 3, 3, 1]) == [1, 12, 0, 4, 6, 1]
    assert sum_consecutives([1, 1, 7, 7, 3]) == [2, 14, 3]
    assert sum_consecutives([-5, -5, 7, 7, 12, 0]) == [-10, 14, 12, 0]
    assert sum_consecutives([3, 3, 3, 3, 1]) == [12, 1]
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")

