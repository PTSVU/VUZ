# Написать функцию two_identical(start, finish), которая определяет количество чисел
# в интервале между числами start и finish (их не считая), в записи которых есть хотя бы две одинаковые цифры.
#
# Примеры:
# max_multiple(20,33) ==> 1 (число 22)
# max_multiple(0,101) ==> 10

import traceback


def two_identical(start, finish):
    # Тело функции
    return 0


# Тесты
try:
    assert two_identical(20, 33) == 1
    assert two_identical(0, 10) == 0
    assert two_identical(0, 101) == 10
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")