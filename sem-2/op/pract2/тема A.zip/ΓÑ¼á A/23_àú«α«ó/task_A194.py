# Написать функцию degree_of_three, которая определяет является ли заданное число кубом какого-либо целого числа.
#
# Примеры:
# degree_of_three(27) ==> True
# degree_of_three(343) ==> True
# degree_of_three(333)  ==> False

import traceback


def degree_of_three(number):
    # Тело функции
    return True


# Тесты
try:
    assert degree_of_three(1) == True
    assert degree_of_three(2) == False
    assert degree_of_three(5) == False
    assert degree_of_three(27) == True
    assert degree_of_three(343) == True
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")