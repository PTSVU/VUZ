# Написать функцию sequence_classifier(arr), которая возвращает тип последовательности.
#
# тип пояснение пример
# 0 неупорядоченная [3,5,8,1,14,3]
# 1 строго возрастающая [3,5,8,9,14,23]
# 2 неубывающая [3,5,8,8,14,14]
# 3 строго убывающая [14,9,8,5,3,1]
# 4 невозрастающая [14,14,8,8,5,3]
# 5 постоянная [8,8,8,8,8,8]
#
# Пример:
# sequence_classifier([8,9]) ==> 1



import traceback


def sequence_classifier(arr):
    # Тело функции
    return 0


# Тесты
try:
    assert sequence_classifier([3, 5, 8, 1, 14, 3]) == 0
    assert sequence_classifier([3, 5, 8, 9, 14, 23]) == 1
    assert sequence_classifier([3, 5, 8, 8, 14, 14]) == 2
    assert sequence_classifier([14, 9, 8, 5, 3, 1]) == 3
    assert sequence_classifier([14, 14, 8, 8, 5, 3]) == 4
    assert sequence_classifier([8, 8, 8, 8, 8, 8]) == 5
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")