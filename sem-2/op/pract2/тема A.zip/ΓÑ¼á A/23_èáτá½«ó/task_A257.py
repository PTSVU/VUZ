# Задан список положительных чисел arr и положительное число k.
# Написать функцию int_diff, которая определяет сколько раз
# разница между двумя различными числами из списка равна k
#
# Пример:
# int_diff([2, 2, 7, 8, 12, 16, 27], 5) ==> 3 ([2, 7], [2, 7], [7, 12])


import traceback


def int_diff(arr, k):
    # Тело функции
    return 0


# Тесты
try:
    assert int_diff([1, 1, 5, 6, 9, 16, 27], 4) == 3
    assert int_diff([1, 1, 3, 3], 2) == 4
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")