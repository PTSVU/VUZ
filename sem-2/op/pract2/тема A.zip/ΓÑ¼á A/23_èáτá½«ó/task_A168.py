# Написать функцию all_different(start, finish), которая определяет количество чисел
# в интервале между числами start и finish (их не считая), в записи которых все цифры разные.
#
# Примеры:
# all_different(20,33) ==> 11 (кроме числа 22)
# all_different(0,101) ==> 90

import traceback


def all_different(start, finish):
    # Тело функции
    return 0


# Тесты
try:
    assert all_different(20, 33) == 11
    assert all_different(0, 10) == 9
    assert all_different(0, 101) == 90
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")