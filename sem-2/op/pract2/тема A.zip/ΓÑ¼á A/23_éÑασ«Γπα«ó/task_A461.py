# Написать функцию xbonacci(signature, n), которая возвращает список из n
# первых членов списка x-боначчи, в котором каждый следующий элемент равен
# сумме х предыдущих, где х - количество элементов в списке signature
#
# Пример:
# xbonacci([1,0,0,0,0,0,1], 10) ==> [1,0,0,0,0,0,1,2,3,6]



import traceback


def xbonacci(signature, n):
    # Тело функции
    return []


# Тесты
try:
    assert xbonacci([0,1],10) == [0,1,1,2,3,5,8,13,21,34]
    assert xbonacci([1,0,0,0,0,0,1],10) == [1,0,0,0,0,0,1,2,3,6]
    assert xbonacci([1,0,0,0,0,0,0,0,0,0],20) == [1,0,0,0,0,0,0,0,0,0,1,1,2,4,8,16,32,64,128,256]
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
