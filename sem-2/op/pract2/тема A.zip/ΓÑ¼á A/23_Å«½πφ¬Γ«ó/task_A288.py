# Написать функцию max_mult(lst), которая возвращает список из двух элементов списка lst, 
# произведение которых будет максимальным. Список lst содержит целые числа.
#
# Пример:
# max_mult([1,2,3,4,5]) ==> [4,5] 
# max_mult([1,2,-3,4,-5]) ==> [-3,-5]


import traceback


def max_mult(lst):
    # Тело функции
    return []


# Тесты
try:
    assert max_mult([1,2,3,4,5]) == [4,5] 
    assert max_mult([1,2,-3,4,-5]) == [-3,-5]
    assert max_mult([4, 6, 2, -3, 0, 5, 1]) == [5, 6]
    assert max_mult([-5,-6,3,4,6,6,1]) == [6, 6]   
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")

