# Написать функцию find_unique(lst), которая возвращает список уникальных элементов.
#
# Пример:
# find_unique([ 1, 1, 1, 2, 1, 1 ]) ==> [2]
# find_unique([ 0, 0, 0.55, 0, 0.66 ]) ==> [0.55,0.66]


import traceback


def find_unique(lst):
    # Тело функции
    return []


# Тесты
try:
    assert find_unique([1, 1, 1, 2, 1, 1]) == [2]
    assert find_unique([0, 0, 0.55, 0, 0.66]) == [0.55, 0.66]
    assert find_unique([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")

