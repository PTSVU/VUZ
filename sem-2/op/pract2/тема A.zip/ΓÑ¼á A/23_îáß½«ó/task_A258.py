# Написать функцию even_numbers, которая получает на вход список целых чисел arr и целое число n и
# возвращает список, состоящий из n последних вхождений четных чисел списка arr в том же порядке.
#
# Пример:
# ([1, 2, 3, 4, 5, 6, 7, 8, 9], 3) => [4, 6, 8]


import traceback


def even_numbers(arr, n):
    # Тело функции
    return []


# Тесты
try:
    assert even_numbers([1, 2, 3, 4, 5, 6, 7, 8, 9], 3) == [4, 6, 8]
    assert even_numbers([-22, 5, 3, 11, 26, -6, -7, -8, -9, -8, 26], 2) == [-8, 26]
    assert even_numbers([6, -25, 3, 7, 5, 5, 7, -3, 23], 1) == [6]
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
