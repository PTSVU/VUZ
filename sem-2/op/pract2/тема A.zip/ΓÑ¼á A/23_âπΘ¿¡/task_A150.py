# Написать функцию max_number(number), которая принимает одно положительное трехзначное целое число 
# и переставляет его цифры, чтобы получить максимально возможное число. 
#
# Примеры:
# max_number(123) => 321

import traceback


def max_number(number):
    # Тело функции
    return True


# Тесты
try:
    assert max_number(123) == 321
    assert max_number(306) == 360
    assert max_number(990) == 990
    assert max_number(196) == 961
    assert max_number(555) ==  555
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")