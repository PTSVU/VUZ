# Написать функцию happy_ticket, которая определяет является ли шестизначное число "счастливым"
# (сумма первых трех цифр равна сумме последних трех цифр)
#
# Пример:
# happy_ticket(003111) ==> True

import traceback


def happy_ticket(number):
    # Тело функции
    return True


# Тесты
try:
    assert happy_ticket(3111) == True # 003111
    assert happy_ticket(101235) == False
    assert happy_ticket(123456) == False
    assert happy_ticket(185536) == True
    assert happy_ticket(713524) == True
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")
