# Написать функцию pyramid(number), которая определит количество уровней пирамиды в бильярде, 
# которую можно собрать с помощью number шаров. 
#
# Примеры:
# pyramid(6) => 3 ->
#    * 
#   * * 
#  * * *


import traceback


def pyramid(number):
    # Тело функции
    return 0


# Тесты
try:
    assert pyramid(1) == 1
    assert pyramid(4) == 2
    assert pyramid(20) == 5
    assert pyramid(100) == 13
    assert pyramid(9999) == 140
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")