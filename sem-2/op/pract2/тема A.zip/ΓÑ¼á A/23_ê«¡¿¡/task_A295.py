# Задан список целых чисел. Написать функцию array_leaders, которая возвращает спсиок всех лидеров.
# Лидер - элемент, больший суммы всех элементов, находящихся справа от него
#
# Пример:
# [1,8,3,4,0] ==> [8,4]


import traceback


def array_leaders(arr):
    # Тело функции
    return []


# Тесты
try:
    assert array_leaders([16,17,4,3,5,2]) == [17,5,2]
    assert array_leaders([-36,-12,-27]) == [-36,-12]
    assert array_leaders([0,-1,-29,3,2]) == [0,-1,3,2]
except AssertionError:
    print("TEST ERROR")
    traceback.print_exc()
else:
    print("TEST PASSED")